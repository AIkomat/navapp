# NavigationApp
 Android app allowing registered users interact with a map
